from logging import root
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import importlib
import mysql.connector as mysql


def loginteacher1():
	root = Tk()
	root.title("PrepMasterBETA")
	root.geometry("1280x720")
	root.resizable(False, False)
	bg = PhotoImage(file = "loginteacher.png")
	label1 = Label( root, image = bg)
	label1.place(x = 0, y = 0)

	user = StringVar()
	passwd = StringVar()
	usernametxt = Entry(root,			
					textvariable=user,
					bg="#0c5dc0",
					justify="center",
					borderwidth=0,
					font="calibri 20",).place(x=443, y=350, width=435, height=55)

	passwordtxt = Entry(bg="#0c5dc0",
					textvariable=passwd,
					justify="center",
					font="calibri 20",
					borderwidth=0,
					show="*").place(x=443, y=470, width=435, height=55)

	def login1(e):
		mycon = mysql.connect(host='localhost', user='root', passwd='comp123', database='prepmaster')
		mycursor = mycon.cursor()
		mycursor.execute('select * from account_teacher;')
		account_teach = mycursor.fetchall()
		if user.get() == account_teach[0][0] and passwd.get() == account_teach[0][1]:
			messagebox.showinfo('showinfo','LOGIN SUCCESSFUL!')
			root.destroy()
			from homepage import homepageaction
			homepageaction()			
		else:
			messagebox.showinfo('showinfo','INVALID USERNAME OR PASSWORD')

	def login2():
		mycon = mysql.connect(host='localhost', user='root', passwd='comp123', database='prepmaster')
		mycursor = mycon.cursor()
		mycursor.execute('select * from account_teacher;')
		account_teach = mycursor.fetchall()
		if user.get() == account_teach[0][0] and passwd.get() == account_teach[0][1]:
			messagebox.showinfo('showinfo','LOGIN SUCCESSFUL!')
			root.destroy()
			from homepage import homepageaction
			homepageaction()
		else:
			messagebox.showinfo('showinfo','INVALID USERNAME OR PASSWORD')
	
	Display = Button(root, 
					text ="START TEACHING!",
					font ="BurbankBigCondensed-Bold 25",
					bg="#57595c",
					command = lambda:login2()).place(x=535, y=552, width=250, height=50)
	root.bind('<Return>',login1)


	root.mainloop()

loginteacher1()