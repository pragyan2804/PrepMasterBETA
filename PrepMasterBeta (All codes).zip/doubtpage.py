import tkinter as tk
from tkinter import messagebox
def doubt():
    root=tk.Tk()
    root.geometry('1280x720')
    root.title('DOUBT')
    root.resizable(False, False)
    root.config(bg='#B327C4')
    root.eval('tk::PlaceWindow . center')
    label_heading = tk.Label(root,
                            text='DOUBT',
                            justify='center',
                            font='BurbankBigCondensed-Bold 70',
                            bg='#B327C4',
                            fg='black',
                            borderwidth=4, width=25, relief='raised').place(x=515, y=10, width=230, height=90)
    label_enterdt= tk.Label(root,
                            text='ENTER YOUR DOUBT HERE',
                            justify='center',
                            font='BurbankBigCondensed-Bold 50',
                            bg= '#B327C4',
                            fg='white',
                            borderwidth=0).place(x=390, y=300, width=500,height=100)
    user=tk.StringVar()
    usernametxt = tk.Entry(root,			
                        textvariable=user,
                        bg="#0c5dc0",
                        justify="center",
                        borderwidth=0,
                        font="calibri 20",).place(x=370, y=400, width=550, height=50)

    def submit():
        messagebox.showinfo('showinfo',"QUERY SUBMITTED")
        root.destroy()

    Display = tk.Button(root,
                        text='SUBMIT',
                        font="BurbankBigCondensed-Bold 17",
                        fg="white",
                        bg="#0072ff",
                        borderwidth=0,
                        command=lambda:submit()).place(x=513, y=500, width=300, height=50)


    label_logo= tk.Label(root,
                        text="PREPMASTER(BETA)",
                        justify='center',
                        bg='#B327C4',
                        fg='black',
                        font='BurbankBigCondensed-Bold 40',
                        borderwidth=0).place(x=900, y=600, width=400, height=100)
        
    root.mainloop()