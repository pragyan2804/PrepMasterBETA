import tkinter as tk

from mcq_ans_check import mcq_ans_check
root=tk.Tk()
root.geometry('1280x720')
root.title('INSTRUCTIONS')
root.resizable(False, False)
root.config(bg='#0073FF')
root.eval('tk::PlaceWindow . center')
label_heading = tk.Label(root,
                        text='INSTRUCTIONS',
                        justify='center',
                        font='BurbankBigCondensed-Bold 70',
                        bg='#0073FF',
                        fg='black',
                        borderwidth=0).place(x=410, y=10, width=500, height=90)
label_inst=tk.Label(root,
                    text="1.YOU CANNOT LEAVE ANY QUESTION UNATTEMPTED.YOU HAVE TO MARK AN OPTION FOR EACH QUESTION.",
                    justify='center',
                    font='BurbankBigCondensed-Bold 27',
                    bg='#0073FF',
                    fg='white',
                    borderwidth=0).place(x=40,y=200,width=1200,height=100)
label_inst1=tk.Label(root,
                    text="2.CLICK NEXT TO GO TO NEXT QUESTION.",
                    justify='center',
                    font='BurbankBigCondensed-Bold 27',
                    bg='#0073FF',
                    fg='white',
                    borderwidth=0).place(x=50,y=300,width=1200,height=100)
def startmcq():
        root.destory()
        from mcq_ans_check import mcq_ans_check
button_start= tk.Button(root,
                        text='START',
                        justify='center',
                        font="BurbankBigCondensed-Bold 40",
                        fg='white',
                        bg='#B327C4',
                        command=lambda:mcq_ans_check()).place(x=500, y=400, width=200, height=70)


root.mainloop()